@echo off
setlocal
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
 echo .NET Framework C# derleyicisi bulunamadi.
 pause
 exit /b 1
)
"%CSC%" /nologo /target:winexe /optimize+ /out:"KameraMiniTarayici.exe" /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "KameraMiniTarayici.cs"
if errorlevel 1 (
 echo.
 echo DERLEME BASARISIZ.
) else (
 echo.
 echo Hazir: KameraMiniTarayici.exe
)
pause
