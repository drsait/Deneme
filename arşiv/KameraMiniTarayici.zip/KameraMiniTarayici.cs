using System;
using System.Drawing;
using System.Windows.Forms;

namespace KameraMiniTarayici
{
    public class MainForm : Form
    {
        TextBox address = new TextBox();
        WebBrowser browser = new WebBrowser();
        Button back = new Button(), forward = new Button(), refresh = new Button(), go = new Button();

        public MainForm()
        {
            Text = "Kamera Mini Tarayıcı (IE Motoru)";
            Width = 1200; Height = 800;
            StartPosition = FormStartPosition.CenterScreen;

            var bar = new Panel { Dock = DockStyle.Top, Height = 38 };
            back.Text = "<"; back.SetBounds(4,5,36,28);
            forward.Text = ">"; forward.SetBounds(44,5,36,28);
            refresh.Text = "Yenile"; refresh.SetBounds(84,5,58,28);
            go.Text = "Git"; go.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            address.SetBounds(148,7,900,24); address.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            go.SetBounds(1054,5,55,28);
            bar.Controls.AddRange(new Control[]{back,forward,refresh,address,go});
            bar.Resize += (s,e) => { address.Width = Math.Max(100, bar.ClientSize.Width - 215); go.Left = bar.ClientSize.Width - 61; };

            browser.Dock = DockStyle.Fill;
            browser.ScriptErrorsSuppressed = true;
            browser.IsWebBrowserContextMenuEnabled = true;
            browser.WebBrowserShortcutsEnabled = true;

            Controls.Add(browser); Controls.Add(bar);

            Action navigate = () => {
                var u = address.Text.Trim();
                if (!u.StartsWith("http://", StringComparison.OrdinalIgnoreCase) && !u.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) u = "http://" + u;
                Uri uri; if (Uri.TryCreate(u, UriKind.Absolute, out uri)) browser.Navigate(uri);
            };
            go.Click += (s,e) => navigate();
            address.KeyDown += (s,e) => { if(e.KeyCode==Keys.Enter){ navigate(); e.SuppressKeyPress=true; } };
            back.Click += (s,e) => { if(browser.CanGoBack) browser.GoBack(); };
            forward.Click += (s,e) => { if(browser.CanGoForward) browser.GoForward(); };
            refresh.Click += (s,e) => browser.Refresh(WebBrowserRefreshOption.Completely);
            browser.Navigated += (s,e) => address.Text = e.Url.ToString();

            Shown += (s,e) => { address.Text = "http://192.168.1.140"; navigate(); };
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
